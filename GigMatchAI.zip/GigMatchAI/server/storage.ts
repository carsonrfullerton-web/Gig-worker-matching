import { 
  type Worker, type InsertWorker,
  type Job, type InsertJob,
  type Application, type InsertApplication
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Worker methods
  getWorker(): Promise<Worker | undefined>;
  createWorker(worker: InsertWorker): Promise<Worker>;
  
  // Job methods
  getJobs(): Promise<Job[]>;
  getJob(id: string): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  
  // Application methods
  getApplications(): Promise<Application[]>;
  getApplicationsByWorker(workerId: string): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
}

export class MemStorage implements IStorage {
  private worker: Worker | undefined;
  private jobs: Map<string, Job>;
  private applications: Map<string, Application>;

  constructor() {
    this.jobs = new Map();
    this.applications = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed some initial jobs
    const sampleJobs: InsertJob[] = [
      {
        title: "Senior Full-Stack Developer",
        company: "TechCorp Solutions",
        description: "We're looking for an experienced full-stack developer to join our team. You'll work on cutting-edge web applications using modern technologies. This role requires strong problem-solving skills and the ability to work independently.\n\nResponsibilities:\n- Build and maintain scalable web applications\n- Collaborate with design and product teams\n- Write clean, maintainable code\n- Mentor junior developers",
        requiredSkills: ["React", "Node.js", "TypeScript", "JavaScript"],
        experienceLevel: "expert",
        payRangeMin: 75,
        payRangeMax: 125,
        location: "San Francisco, CA (Remote)",
        jobType: "development",
        postedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        featured: true,
      },
      {
        title: "UI/UX Designer",
        company: "Creative Studios",
        description: "Join our creative team to design beautiful, user-friendly interfaces for web and mobile applications. We value designers who can think holistically about user experience.\n\nWhat you'll do:\n- Create wireframes and high-fidelity mockups\n- Conduct user research and usability testing\n- Collaborate with developers to implement designs\n- Maintain and evolve our design system",
        requiredSkills: ["UI/UX Design", "Graphic Design"],
        experienceLevel: "intermediate",
        payRangeMin: 50,
        payRangeMax: 85,
        location: "New York, NY",
        jobType: "design",
        postedDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        featured: false,
      },
      {
        title: "Content Writer",
        company: "Marketing Plus",
        description: "We need a talented content writer to create engaging blog posts, articles, and marketing copy. SEO knowledge is a plus.\n\nYou'll be writing about:\n- Technology trends\n- Digital marketing strategies\n- Business growth tips\n- Industry insights",
        requiredSkills: ["Content Writing", "SEO", "Marketing"],
        experienceLevel: "intermediate",
        payRangeMin: 35,
        payRangeMax: 60,
        location: "Remote",
        jobType: "writing",
        postedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        featured: false,
      },
      {
        title: "Python Data Analyst",
        company: "DataViz Inc",
        description: "Analyze large datasets and create insightful visualizations to drive business decisions. Experience with Python, pandas, and data visualization libraries required.\n\nKey responsibilities:\n- Clean and process large datasets\n- Build dashboards and reports\n- Identify trends and patterns\n- Present findings to stakeholders",
        requiredSkills: ["Python", "Data Analysis", "Excel"],
        experienceLevel: "intermediate",
        payRangeMin: 60,
        payRangeMax: 95,
        location: "Austin, TX (Hybrid)",
        jobType: "development",
        postedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        featured: false,
      },
      {
        title: "Video Editor",
        company: "Media Productions",
        description: "Edit engaging video content for social media, YouTube, and marketing campaigns. Must be proficient with modern editing software.\n\nProjects include:\n- Short-form social media content\n- Product demonstrations\n- Customer testimonials\n- Educational videos",
        requiredSkills: ["Video Editing", "Photography"],
        experienceLevel: "entry",
        payRangeMin: 30,
        payRangeMax: 55,
        location: "Los Angeles, CA",
        jobType: "marketing",
        postedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        featured: false,
      },
      {
        title: "React Native Developer",
        company: "MobileFirst Apps",
        description: "Build cross-platform mobile applications using React Native. Work with a talented team to create innovative mobile experiences.\n\nYou'll need:\n- Strong React and JavaScript skills\n- Mobile development experience\n- Understanding of iOS and Android platforms\n- Ability to write clean, testable code",
        requiredSkills: ["React", "JavaScript", "TypeScript"],
        experienceLevel: "intermediate",
        payRangeMin: 65,
        payRangeMax: 100,
        location: "Remote",
        jobType: "development",
        postedDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        featured: true,
      },
    ];

    sampleJobs.forEach(job => {
      const id = randomUUID();
      this.jobs.set(id, { ...job, id });
    });
  }

  // Worker methods
  async getWorker(): Promise<Worker | undefined> {
    return this.worker;
  }

  async createWorker(insertWorker: InsertWorker): Promise<Worker> {
    const id = randomUUID();
    const worker: Worker = { ...insertWorker, id };
    this.worker = worker;
    return worker;
  }

  // Job methods
  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values());
  }

  async getJob(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = randomUUID();
    const job: Job = { ...insertJob, id };
    this.jobs.set(id, job);
    return job;
  }

  // Application methods
  async getApplications(): Promise<Application[]> {
    return Array.from(this.applications.values());
  }

  async getApplicationsByWorker(workerId: string): Promise<Application[]> {
    return Array.from(this.applications.values()).filter(
      app => app.workerId === workerId
    );
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = randomUUID();
    const application: Application = { ...insertApplication, id };
    this.applications.set(id, application);
    return application;
  }
}

export const storage = new MemStorage();
