import OpenAI from "openai";
import type { Worker, Job, MatchResult } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function calculateJobMatch(
  worker: Worker,
  job: Job
): Promise<MatchResult> {
  try {
    const prompt = `You are an expert job matching AI. Analyze how well a worker's profile matches a job posting.

Worker Profile:
- Skills: ${worker.skills.join(", ")}
- Experience Level: ${worker.experienceLevel}
- Hourly Rate: $${worker.hourlyRate}
- Location: ${worker.location}
- Availability: ${worker.availability}

Job Requirements:
- Title: ${job.title}
- Required Skills: ${job.requiredSkills.join(", ")}
- Experience Level: ${job.experienceLevel}
- Pay Range: $${job.payRangeMin} - $${job.payRangeMax}/hr
- Location: ${job.location}
- Job Type: ${job.jobType}

Calculate:
1. Overall match score (0-100)
2. Individual skill match percentages for each required skill
3. Brief reasoning for the match score

Respond in JSON format with this structure:
{
  "matchScore": number (0-100),
  "reasoning": string (2-3 sentences explaining the match),
  "skillBreakdown": [
    { "skill": string, "match": number (0-100) }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert job matching system. Provide accurate, helpful match scores and insights."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      jobId: job.id,
      matchScore: Math.max(0, Math.min(100, Math.round(result.matchScore || 0))),
      reasoning: result.reasoning || "Match calculated based on skills and experience.",
      skillBreakdown: result.skillBreakdown || []
    };
  } catch (error) {
    console.error("AI matching error:", error);
    
    // Fallback to simple matching if AI fails
    const workerSkillsSet = new Set(worker.skills.map(s => s.toLowerCase()));
    const matchedSkills = job.requiredSkills.filter(skill => 
      workerSkillsSet.has(skill.toLowerCase())
    );
    
    const skillMatchPercentage = job.requiredSkills.length > 0
      ? (matchedSkills.length / job.requiredSkills.length) * 100
      : 0;
    
    // Factor in experience level
    const experienceLevels = { entry: 1, intermediate: 2, expert: 3 };
    const workerLevel = experienceLevels[worker.experienceLevel as keyof typeof experienceLevels] || 2;
    const jobLevel = experienceLevels[job.experienceLevel as keyof typeof experienceLevels] || 2;
    const experienceMatch = Math.max(0, 100 - Math.abs(workerLevel - jobLevel) * 20);
    
    // Factor in pay rate
    const payMatch = worker.hourlyRate >= job.payRangeMin && worker.hourlyRate <= job.payRangeMax
      ? 100
      : worker.hourlyRate < job.payRangeMin
        ? Math.max(0, 100 - ((job.payRangeMin - worker.hourlyRate) / job.payRangeMin) * 50)
        : Math.max(0, 100 - ((worker.hourlyRate - job.payRangeMax) / job.payRangeMax) * 50);
    
    const overallMatch = Math.round(
      skillMatchPercentage * 0.6 + experienceMatch * 0.25 + payMatch * 0.15
    );
    
    const skillBreakdown = job.requiredSkills.map(skill => ({
      skill,
      match: workerSkillsSet.has(skill.toLowerCase()) ? 95 : 30
    }));

    return {
      jobId: job.id,
      matchScore: Math.max(0, Math.min(100, overallMatch)),
      reasoning: `Based on ${matchedSkills.length} of ${job.requiredSkills.length} matching skills and compatible experience level.`,
      skillBreakdown
    };
  }
}

export async function calculateAllMatches(
  worker: Worker,
  jobs: Job[]
): Promise<MatchResult[]> {
  const matchPromises = jobs.map(job => calculateJobMatch(worker, job));
  return Promise.all(matchPromises);
}
