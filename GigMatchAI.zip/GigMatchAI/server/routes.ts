import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { calculateAllMatches, calculateJobMatch } from "./ai-matcher";
import { insertWorkerSchema, insertJobSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Worker routes
  app.get("/api/worker", async (req, res) => {
    try {
      const worker = await storage.getWorker();
      if (!worker) {
        return res.status(404).json({ message: "Worker profile not found" });
      }
      res.json(worker);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch worker profile" });
    }
  });

  app.post("/api/worker", async (req, res) => {
    try {
      const validatedData = insertWorkerSchema.parse(req.body);
      const worker = await storage.createWorker(validatedData);
      res.status(201).json(worker);
    } catch (error) {
      res.status(400).json({ message: "Invalid worker data", error });
    }
  });

  // Job routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const validatedData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(validatedData);
      res.status(201).json(job);
    } catch (error) {
      res.status(400).json({ message: "Invalid job data", error });
    }
  });

  // Match routes - AI-powered matching
  app.get("/api/matches", async (req, res) => {
    try {
      const worker = await storage.getWorker();
      if (!worker) {
        return res.status(404).json({ message: "Worker profile not found. Please create a profile first." });
      }

      const jobs = await storage.getJobs();
      const matches = await calculateAllMatches(worker, jobs);
      
      res.json(matches);
    } catch (error) {
      console.error("Match calculation error:", error);
      res.status(500).json({ message: "Failed to calculate matches" });
    }
  });

  app.get("/api/match/:jobId", async (req, res) => {
    try {
      const worker = await storage.getWorker();
      if (!worker) {
        return res.status(404).json({ message: "Worker profile not found" });
      }

      const job = await storage.getJob(req.params.jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      const match = await calculateJobMatch(worker, job);
      res.json(match);
    } catch (error) {
      console.error("Match calculation error:", error);
      res.status(500).json({ message: "Failed to calculate match" });
    }
  });

  // Application routes
  app.get("/api/applications", async (req, res) => {
    try {
      const worker = await storage.getWorker();
      if (!worker) {
        return res.json([]);
      }

      const applications = await storage.getApplicationsByWorker(worker.id);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.post("/api/apply", async (req, res) => {
    try {
      const { jobId } = req.body;
      
      if (!jobId || typeof jobId !== 'string') {
        return res.status(400).json({ message: "Job ID is required" });
      }
      
      const worker = await storage.getWorker();
      if (!worker) {
        return res.status(404).json({ message: "Worker profile not found. Please create your profile first." });
      }

      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      // Calculate match for this application
      const match = await calculateJobMatch(worker, job);

      const application = await storage.createApplication({
        workerId: worker.id,
        jobId: job.id,
        matchScore: match.matchScore,
        status: "pending",
        appliedDate: new Date().toISOString(),
        skillBreakdown: JSON.stringify(match.skillBreakdown),
      });

      res.status(201).json(application);
    } catch (error: any) {
      console.error("Application error:", error);
      res.status(500).json({ 
        message: "Failed to submit application", 
        error: error.message || "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
