# Design Guidelines: AI-Powered Gig Worker Job Matching Platform

## Design Approach

**Hybrid Approach**: Drawing from LinkedIn's professional polish + Upwork's job marketplace patterns + Linear's clean dashboard aesthetics. This platform prioritizes trust-building (professional visual identity) while maintaining high information density for efficient job browsing.

**Core Principle**: Balance credibility with accessibility—gig workers need a platform that feels professional yet approachable, with AI-powered features that feel intelligent, not overwhelming.

---

## Typography System

**Font Stack**:
- Primary: Inter (400, 500, 600, 700) - body text, UI elements
- Display: Cal Sans or Satoshi (700) - headlines, hero text

**Hierarchy**:
- Hero Headlines: 48-64px (mobile: 32-40px), display font, letter-spacing -0.02em
- Section Headers: 32-40px, display font
- Job Titles: 20-24px, semi-bold
- Match Scores: 28-32px, bold (numerical emphasis)
- Body Text: 16px, regular (line-height 1.6)
- Metadata/Tags: 14px, medium
- Small Print: 13px, regular

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16, 20** for consistent rhythm
- Component padding: p-6 to p-8
- Section spacing: py-16 to py-24
- Card gaps: gap-6
- Content max-width: max-w-7xl

**Grid Strategy**:
- Job listings: 3-column grid (lg:grid-cols-3) → 2-col tablet → 1-col mobile
- Worker profiles: 2-column split (details + stats)
- Match dashboard: Single column with card layout

---

## Core Components

### Navigation
**Top Navigation Bar**:
- Fixed header with slight blur backdrop
- Logo left, navigation center (Jobs, My Applications, Messages, Profile)
- Right: Notification bell + profile avatar + "Post a Job" CTA button
- Search bar integrated into nav (expandable on mobile)

### Hero Section (Landing)
**Layout**: Split hero (60/40)
- Left: Bold headline "Find Your Next Gig in Minutes" + subheading + dual CTAs ("I'm Looking for Work" + "I'm Hiring")
- Right: Hero illustration showing diverse gig workers + floating UI cards displaying match scores (92%, 88%, etc.)
- Height: 85vh with gradient background treatment

**Images**: Hero requires custom illustration or high-quality stock image showing happy, diverse gig workers. Floating UI mockup cards overlay the image showing the AI matching interface.

### Job Cards
**Structure**:
- Card container with subtle border, rounded-lg, p-6
- Top row: Job title (bold, 20px) + Company logo (48x48px, rounded)
- Second row: Location icon + location, Clock icon + posted time
- Skills row: Tag pills for required skills (rounded-full, px-4, py-1.5)
- Match score badge: Prominent circular badge (top-right corner) showing percentage with AI sparkle icon
- Bottom: Pay range (bold) + "Apply Now" button (full-width on mobile, right-aligned desktop)

### Match Score Display
**Visual Treatment**:
- Large circular progress indicator (120px diameter)
- Percentage in center (32px, bold)
- Color-coded rings: 90-100% (success), 70-89% (warning), <70% (neutral)
- AI badge/icon below showing "AI Match"
- Breakdown bars below showing skill alignment (e.g., "React: 95%", "Node.js: 87%")

### Worker Profile Dashboard
**Layout**:
- Profile header: Avatar (120px) + name + headline + edit button
- Stats bar: Applications sent, Match rate average, Profile views (3-column grid)
- Skills section: Tag cloud with proficiency levels (beginner/intermediate/expert badges)
- Experience timeline: Card-based list with company logos
- Preferences panel: Availability, desired pay range, location preferences

### Job Listing Dashboard
**Components**:
- Filter sidebar (left, 280px wide): Categories, Pay range sliders, Location autocomplete, Skills checkboxes, Date posted
- Main content area: Sort dropdown + view toggle (grid/list)
- Job cards grid with infinite scroll
- Quick apply modal with resume upload + cover letter

### Application Tracking
**Table Layout**:
- Columns: Job Title, Company, Applied Date, Match Score, Status
- Status badges: "Under Review", "Interview", "Rejected", "Accepted"
- Expandable rows showing application timeline
- Filter tabs: All, Pending, Interviewed, Offers

---

## Interactive Elements

### Buttons
**Primary CTA**: Solid fill, rounded-lg, px-6 py-3, medium weight text, hover lift (2px translate)
**Secondary**: Border style, same dimensions
**Icon Buttons**: 40x40px, rounded-full, icon centered
**Buttons on Hero Image**: Semi-transparent background with backdrop-blur-md

### Form Inputs
**Text Fields**: 
- Height: h-12, rounded-lg, px-4
- Border: 1.5px, focus ring with 3px offset
- Label: 14px medium, mb-2

**Skill Tags Input**: 
- Multi-select with autocomplete
- Selected tags appear as removable pills below input

### Cards
**Standard Job Card**: rounded-xl, border, p-6, hover shadow transition
**Featured Job Card**: Gradient border, slightly larger, "Featured" ribbon
**Profile Card**: Avatar-focused with stats overlay

---

## Animations

**Minimal Approach**:
- Match score: Animated counter on reveal (count-up effect)
- Card hover: Subtle lift (translateY(-4px)) + shadow increase
- Page transitions: Simple fade (200ms)
- Loading states: Skeleton screens for job cards
- No scroll-triggered animations

---

## Page-Specific Layouts

### Landing Page (Marketing)
1. **Hero**: Split layout as described above (85vh)
2. **How It Works**: 3-column feature cards with icons, titles, descriptions (py-20)
3. **AI Matching Demo**: Interactive mockup showing skill input → AI analysis → job matches (py-24)
4. **Success Stories**: 2-column testimonial grid with worker photos + match scores achieved
5. **Categories**: 6-column icon grid of job categories (gig types)
6. **CTA Section**: Centered with dual paths (workers vs employers)
7. **Footer**: 4-column (Company, For Workers, For Employers, Support) + newsletter signup

### Worker Dashboard
**Layout**: Sidebar navigation (240px) + main content area
- Top stats overview cards (3-column)
- "Recommended Jobs" section (AI-curated based on profile)
- Recent activity feed
- Profile completion meter

### Job Posting Flow (Employer)
**Multi-step Form**:
- Step indicator progress bar
- Job details → Skills required → Budget & timeline → Preview → Publish
- Right sidebar showing preview card as they type

---

## Icons
**Library**: Heroicons (via CDN)
- Navigation: outline variants
- UI actions: solid variants
- Feature sections: 24x24px custom AI-themed icons for matching, verification, etc.

---

## Images

**Required Images**:
1. **Landing Hero**: Diverse gig workers collaborating (right side, 60% width). Overlay with floating UI mockup cards showing match interface
2. **How It Works Section**: 3 illustrations showing profile creation → AI analysis → job matches
3. **Testimonials**: Real or stock photos of workers (square crops, 80x80px)
4. **Category Icons**: Simple SVG icons for each gig category (design, development, writing, etc.)

**Treatment**: All images use rounded corners (rounded-xl), subtle shadow, and maintain consistent aspect ratios (hero: 16:10, testimonials: 1:1)