import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const workers = pgTable("workers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  headline: text("headline").notNull(),
  skills: text("skills").array().notNull(),
  experienceLevel: text("experience_level").notNull(),
  hourlyRate: integer("hourly_rate").notNull(),
  location: text("location").notNull(),
  availability: text("availability").notNull(),
  bio: text("bio"),
});

export const jobs = pgTable("jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  company: text("company").notNull(),
  description: text("description").notNull(),
  requiredSkills: text("required_skills").array().notNull(),
  experienceLevel: text("experience_level").notNull(),
  payRangeMin: integer("pay_range_min").notNull(),
  payRangeMax: integer("pay_range_max").notNull(),
  location: text("location").notNull(),
  jobType: text("job_type").notNull(),
  postedDate: text("posted_date").notNull(),
  featured: boolean("featured").default(false),
});

export const applications = pgTable("applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workerId: text("worker_id").notNull(),
  jobId: text("job_id").notNull(),
  matchScore: integer("match_score").notNull(),
  status: text("status").notNull(),
  appliedDate: text("applied_date").notNull(),
  skillBreakdown: text("skill_breakdown").notNull(),
});

export const insertWorkerSchema = createInsertSchema(workers).omit({ id: true });
export const insertJobSchema = createInsertSchema(jobs).omit({ id: true });
export const insertApplicationSchema = createInsertSchema(applications).omit({ id: true });

export type Worker = typeof workers.$inferSelect;
export type InsertWorker = z.infer<typeof insertWorkerSchema>;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Application = typeof applications.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;

export interface MatchResult {
  jobId: string;
  matchScore: number;
  reasoning: string;
  skillBreakdown: Array<{ skill: string; match: number }>;
}
