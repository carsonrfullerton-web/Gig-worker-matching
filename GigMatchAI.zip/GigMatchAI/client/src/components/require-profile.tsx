import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { User } from "lucide-react";
import type { Worker } from "@shared/schema";

interface RequireProfileProps {
  children: React.ReactNode;
}

export function RequireProfile({ children }: RequireProfileProps) {
  const [, navigate] = useLocation();
  const { data: worker, isLoading } = useQuery<Worker>({
    queryKey: ["/api/worker"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="p-12">
            <Skeleton className="h-12 w-12 mx-auto mb-4 rounded-full" />
            <Skeleton className="h-6 w-3/4 mx-auto mb-2" />
            <Skeleton className="h-4 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!worker) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card className="max-w-md w-full">
          <CardContent className="p-12 text-center">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <User className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-2xl font-bold mb-2">Create Your Profile First</h3>
            <p className="text-muted-foreground mb-6">
              You need to create a worker profile before you can browse jobs and apply. 
              Tell us about your skills and experience to get matched with perfect opportunities.
            </p>
            <div className="space-y-3">
              <Button 
                className="w-full" 
                onClick={() => navigate("/profile")}
                data-testid="button-create-profile-prompt"
              >
                Create Profile Now
              </Button>
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={() => navigate("/")}
                data-testid="button-back-home-prompt"
              >
                Back to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}
