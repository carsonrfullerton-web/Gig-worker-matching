import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Sparkles, ArrowLeft, Calendar, TrendingUp, Briefcase, 
  FileText, Clock, CheckCircle2 
} from "lucide-react";
import { type Application, type Job } from "@shared/schema";

export default function Applications() {
  const [activeTab, setActiveTab] = useState("all");

  const { data: applications, isLoading: applicationsLoading } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
  });

  const { data: jobs, isLoading: jobsLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const getJob = (jobId: string) => {
    return jobs?.find(j => j.id === jobId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/10 text-yellow-700 border-yellow-200";
      case "reviewed":
        return "bg-blue-500/10 text-blue-700 border-blue-200";
      case "interview":
        return "bg-purple-500/10 text-purple-700 border-purple-200";
      case "accepted":
        return "bg-green-500/10 text-green-700 border-green-200";
      case "rejected":
        return "bg-red-500/10 text-red-700 border-red-200";
      default:
        return "bg-muted";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "reviewed":
        return <FileText className="h-4 w-4" />;
      case "interview":
        return <Calendar className="h-4 w-4" />;
      case "accepted":
        return <CheckCircle2 className="h-4 w-4" />;
      default:
        return <Briefcase className="h-4 w-4" />;
    }
  };

  const filteredApplications = applications?.filter(app => {
    if (activeTab === "all") return true;
    if (activeTab === "pending") return app.status === "pending" || app.status === "reviewed";
    if (activeTab === "interview") return app.status === "interview";
    if (activeTab === "offers") return app.status === "accepted";
    return false;
  }) || [];

  const isLoading = applicationsLoading || jobsLoading;

  const stats = {
    total: applications?.length || 0,
    pending: applications?.filter(a => a.status === "pending" || a.status === "reviewed").length || 0,
    interviews: applications?.filter(a => a.status === "interview").length || 0,
    offers: applications?.filter(a => a.status === "accepted").length || 0,
    avgMatchScore: applications?.length 
      ? Math.round(applications.reduce((sum, a) => sum + a.matchScore, 0) / applications.length)
      : 0,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => window.history.back()} data-testid="button-back">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="font-bold">GigMatch</span>
            </div>
          </div>
          <Link href="/jobs">
            <Button data-testid="button-browse-more-jobs">Browse More Jobs</Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-12 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">My Applications</h1>
          <p className="text-muted-foreground">
            Track and manage all your job applications in one place
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Briefcase className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats.total}</div>
                  <div className="text-xs text-muted-foreground">Total</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats.pending}</div>
                  <div className="text-xs text-muted-foreground">Pending</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats.interviews}</div>
                  <div className="text-xs text-muted-foreground">Interviews</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats.offers}</div>
                  <div className="text-xs text-muted-foreground">Offers</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats.avgMatchScore}%</div>
                  <div className="text-xs text-muted-foreground">Avg Match</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Applications List */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="all" data-testid="tab-all">All</TabsTrigger>
            <TabsTrigger value="pending" data-testid="tab-pending">Pending</TabsTrigger>
            <TabsTrigger value="interview" data-testid="tab-interview">Interviews</TabsTrigger>
            <TabsTrigger value="offers" data-testid="tab-offers">Offers</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-3/4 mb-4" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredApplications.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No applications yet</h3>
                  <p className="text-muted-foreground mb-6">
                    Start browsing jobs to find your perfect match
                  </p>
                  <Link href="/jobs">
                    <Button data-testid="button-empty-state-browse">
                      Browse Jobs
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {filteredApplications.map((application) => {
                  const job = getJob(application.jobId);
                  if (!job) return null;

                  const skillBreakdown = JSON.parse(application.skillBreakdown);

                  return (
                    <Card key={application.id} className="hover-elevate transition-all">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start gap-4 mb-3">
                              <div className="flex-1 min-w-0">
                                <h3 className="text-xl font-semibold mb-1 truncate">
                                  {job.title}
                                </h3>
                                <p className="text-muted-foreground mb-2">{job.company}</p>
                                <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    Applied {new Date(application.appliedDate).toLocaleDateString()}
                                  </span>
                                </div>
                              </div>
                              <div className="text-center shrink-0">
                                <div className="text-2xl font-bold text-primary">
                                  {application.matchScore}%
                                </div>
                                <div className="text-xs text-muted-foreground">Match</div>
                              </div>
                            </div>

                            {/* Skill Breakdown */}
                            {skillBreakdown && skillBreakdown.length > 0 && (
                              <div className="flex flex-wrap gap-2 mb-3">
                                {skillBreakdown.slice(0, 4).map((sb: any) => (
                                  <Badge key={sb.skill} variant="secondary" className="text-xs">
                                    {sb.skill}: {sb.match}%
                                  </Badge>
                                ))}
                                {skillBreakdown.length > 4 && (
                                  <Badge variant="secondary" className="text-xs">
                                    +{skillBreakdown.length - 4} more
                                  </Badge>
                                )}
                              </div>
                            )}
                          </div>

                          <div className="flex flex-col gap-3 items-end">
                            <Badge className={`${getStatusColor(application.status)} flex items-center gap-1.5 px-3 py-1`}>
                              {getStatusIcon(application.status)}
                              <span className="capitalize">{application.status}</span>
                            </Badge>
                            <Link href={`/job/${job.id}`}>
                              <Button variant="outline" size="sm" data-testid={`button-view-job-${job.id}`}>
                                View Job
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
