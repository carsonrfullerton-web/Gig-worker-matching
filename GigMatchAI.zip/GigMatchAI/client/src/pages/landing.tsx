import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Users, Zap, CheckCircle2, ArrowRight } from "lucide-react";
import heroImage from "@assets/generated_images/Diverse_gig_workers_collaborating_d7cc48a6.png";

export default function Landing() {
  const categories = [
    { name: "Design", icon: "🎨" },
    { name: "Development", icon: "💻" },
    { name: "Writing", icon: "✍️" },
    { name: "Marketing", icon: "📱" },
    { name: "Video", icon: "🎬" },
    { name: "Consulting", icon: "💼" },
  ];

  const features = [
    {
      icon: Sparkles,
      title: "AI-Powered Matching",
      description: "Our intelligent algorithm analyzes your skills and preferences to find perfect job matches with precision accuracy."
    },
    {
      icon: TrendingUp,
      title: "Smart Score System",
      description: "See exactly how well you match each opportunity with detailed compatibility scores and skill breakdowns."
    },
    {
      icon: Zap,
      title: "Instant Applications",
      description: "Apply to multiple opportunities in seconds and track all your applications in one convenient dashboard."
    }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Freelance Designer",
      score: 94,
      quote: "Found my dream project in under 10 minutes. The AI matching is incredibly accurate!"
    },
    {
      name: "Marcus Rodriguez",
      role: "Full-Stack Developer",
      score: 92,
      quote: "The match scores helped me focus on the right opportunities. Saved so much time!"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">GigMatch</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#how-it-works" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              How It Works
            </a>
            <a href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#categories" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Categories
            </a>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/jobs">
              <Button variant="ghost" data-testid="button-browse-jobs">Browse Jobs</Button>
            </Link>
            <Link href="/profile">
              <Button data-testid="button-get-started">Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        <div className="container mx-auto px-6 py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-hero-mobile md:text-hero font-bold tracking-tight">
                  Find Your Next Gig in <span className="text-primary">Minutes</span>
                </h1>
                <p className="text-lg text-muted-foreground max-w-xl">
                  AI-powered job matching connects you with opportunities that perfectly align with your skills, experience, and preferences.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/profile">
                  <Button size="lg" className="w-full sm:w-auto" data-testid="button-hero-looking-for-work">
                    I'm Looking for Work
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/post-job">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto" data-testid="button-hero-hiring">
                    I'm Hiring
                  </Button>
                </Link>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-muted-foreground" />
                  <div className="text-sm">
                    <div className="font-semibold">10,000+</div>
                    <div className="text-muted-foreground">Active Workers</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-muted-foreground" />
                  <div className="text-sm">
                    <div className="font-semibold">5,000+</div>
                    <div className="text-muted-foreground">Jobs Posted</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="relative rounded-xl overflow-hidden">
                <img 
                  src={heroImage} 
                  alt="Diverse gig workers collaborating" 
                  className="w-full h-auto rounded-xl"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
              </div>
              {/* Floating Match Score Cards */}
              <Card className="absolute -bottom-6 -left-6 w-48 border-2">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-primary">92%</div>
                      <div className="text-xs text-muted-foreground">Match Score</div>
                    </div>
                    <Sparkles className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
              <Card className="absolute -top-6 -right-6 w-40 border-2 hidden lg:block">
                <CardContent className="p-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <div className="text-xs font-medium">AI Verified</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-card/50">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-section font-bold">How It Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Get matched with your perfect opportunities in three simple steps
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "1", title: "Create Your Profile", desc: "Add your skills, experience, and preferences to build your professional profile." },
              { step: "2", title: "AI Analysis", desc: "Our intelligent system analyzes thousands of opportunities to find your perfect matches." },
              { step: "3", title: "Get Matched", desc: "Review your top matches with detailed scores and apply to opportunities instantly." }
            ].map((item) => (
              <Card key={item.step} className="relative overflow-hidden hover-elevate transition-transform">
                <div className="absolute top-0 right-0 text-8xl font-bold text-primary/5">
                  {item.step}
                </div>
                <CardContent className="p-8 relative">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <span className="text-2xl font-bold text-primary">{item.step}</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-section font-bold">Powerful Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to find and secure your next opportunity
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <Card key={feature.title} className="hover-elevate transition-transform">
                  <CardContent className="p-8">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section id="categories" className="py-20 bg-card/50">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-section font-bold">Popular Categories</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Find opportunities across diverse industries and skill sets
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Card key={category.name} className="hover-elevate active-elevate-2 cursor-pointer transition-transform">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-2">{category.icon}</div>
                  <div className="font-medium">{category.name}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-section font-bold">Success Stories</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              See how GigMatch has helped workers find their perfect opportunities
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.name} className="hover-elevate transition-transform">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="h-16 w-16 rounded-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center text-white font-bold text-xl">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                      <Badge variant="secondary" className="mt-2">
                        {testimonial.score}% Match Score
                      </Badge>
                    </div>
                  </div>
                  <p className="text-muted-foreground italic">"{testimonial.quote}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-6 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-section font-bold">Ready to Find Your Perfect Gig?</h2>
            <p className="text-lg opacity-90">
              Join thousands of workers who have found their ideal opportunities with AI-powered matching
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/profile">
                <Button size="lg" variant="secondary" className="w-full sm:w-auto" data-testid="button-cta-worker">
                  Create Worker Profile
                </Button>
              </Link>
              <Link href="/post-job">
                <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent text-primary-foreground border-primary-foreground hover:bg-primary-foreground/10" data-testid="button-cta-employer">
                  Post a Job
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 bg-card/30">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="h-5 w-5 text-primary" />
                <span className="font-bold">GigMatch</span>
              </div>
              <p className="text-sm text-muted-foreground">
                AI-powered job matching for the modern gig economy
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">For Workers</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Browse Jobs</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Create Profile</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">How It Works</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">For Employers</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Post a Job</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Find Workers</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">About</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Privacy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t pt-8 text-center text-sm text-muted-foreground">
            © 2024 GigMatch. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
