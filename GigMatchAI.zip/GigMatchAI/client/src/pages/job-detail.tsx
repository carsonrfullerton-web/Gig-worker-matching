import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  Sparkles, ArrowLeft, MapPin, DollarSign, Clock, Briefcase, 
  Building2, TrendingUp, CheckCircle2 
} from "lucide-react";
import { type Job, type MatchResult } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function JobDetail() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: job, isLoading: jobLoading } = useQuery<Job>({
    queryKey: ["/api/jobs", id],
  });

  const { data: match, isLoading: matchLoading } = useQuery<MatchResult>({
    queryKey: ["/api/match", id],
  });

  const applyMutation = useMutation({
    mutationFn: async (jobId: string) => {
      return await apiRequest("POST", "/api/apply", { jobId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Application submitted!",
        description: "Your application has been submitted successfully.",
      });
      navigate("/applications");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (jobLoading || matchLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card/50">
          <div className="container mx-auto flex h-16 items-center px-6">
            <Skeleton className="h-8 w-32" />
          </div>
        </header>
        <div className="container mx-auto px-6 py-12 max-w-5xl">
          <Skeleton className="h-12 w-3/4 mb-4" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <Skeleton className="h-64" />
              <Skeleton className="h-48" />
            </div>
            <div className="space-y-6">
              <Skeleton className="h-96" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardContent className="p-12 text-center">
            <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">Job not found</h3>
            <p className="text-muted-foreground mb-4">
              The job you're looking for doesn't exist or has been removed.
            </p>
            <Button onClick={() => navigate("/jobs")} data-testid="button-back-to-jobs">
              Back to Jobs
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const matchScore = match?.matchScore || 0;
  const matchColor = 
    matchScore >= 80 ? "text-green-600" : 
    matchScore >= 60 ? "text-orange-600" : 
    "text-muted-foreground";

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <Button variant="ghost" onClick={() => navigate("/jobs")} data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Jobs
          </Button>
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <span className="font-bold">GigMatch</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-12 max-w-5xl">
        {/* Job Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between gap-6 mb-4">
            <div className="flex-1">
              <h1 className="text-4xl font-bold mb-2">{job.title}</h1>
              <div className="flex items-center gap-2 text-lg text-muted-foreground">
                <Building2 className="h-5 w-5" />
                {job.company}
              </div>
            </div>
            {job.featured && (
              <Badge className="text-base px-4 py-1">Featured</Badge>
            )}
          </div>
          
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              {job.location}
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <DollarSign className="h-4 w-4" />
              ${job.payRangeMin} - ${job.payRangeMax}/hr
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              Posted {new Date(job.postedDate).toLocaleDateString()}
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Briefcase className="h-4 w-4" />
              {job.jobType}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Job Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Job Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
                  {job.description}
                </p>
              </CardContent>
            </Card>

            {/* Required Skills */}
            <Card>
              <CardHeader>
                <CardTitle>Required Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {job.requiredSkills.map((skill) => (
                    <Badge key={skill} variant="secondary" className="text-sm px-3 py-1">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Experience Level */}
            <Card>
              <CardHeader>
                <CardTitle>Experience Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <span className="font-medium capitalize">{job.experienceLevel} Level</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Match Score & Apply */}
          <div className="space-y-6">
            {/* Match Score Card */}
            {matchScore > 0 && (
              <Card className="border-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    AI Match Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Overall Score */}
                  <div className="text-center">
                    <div className={`text-5xl font-bold mb-2 ${matchColor}`}>
                      {matchScore}%
                    </div>
                    <div className="text-sm text-muted-foreground">Overall Match Score</div>
                  </div>

                  {/* Skill Breakdown */}
                  {match?.skillBreakdown && match.skillBreakdown.length > 0 && (
                    <div className="space-y-4">
                      <div className="text-sm font-semibold">Skill Match Breakdown</div>
                      {match.skillBreakdown.map(({ skill, match: skillMatch }) => (
                        <div key={skill} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span>{skill}</span>
                            <span className="font-semibold">{skillMatch}%</span>
                          </div>
                          <Progress value={skillMatch} className="h-2" />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reasoning */}
                  {match?.reasoning && (
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <div className="text-xs font-semibold mb-2 text-muted-foreground uppercase tracking-wide">
                        Why This Match?
                      </div>
                      <p className="text-sm leading-relaxed">{match.reasoning}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Apply Card */}
            <Card>
              <CardHeader>
                <CardTitle>Ready to Apply?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span>Your profile matches {matchScore}% of requirements</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span>Fast application process</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span>Track your application status</span>
                  </div>
                </div>
                
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={() => applyMutation.mutate(job.id)}
                  disabled={applyMutation.isPending}
                  data-testid="button-apply"
                >
                  {applyMutation.isPending ? "Applying..." : "Apply Now"}
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  Your profile information will be sent to the employer
                </p>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Job Type</span>
                  <span className="font-medium capitalize">{job.jobType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Experience</span>
                  <span className="font-medium capitalize">{job.experienceLevel}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Skills Required</span>
                  <span className="font-medium">{job.requiredSkills.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Posted</span>
                  <span className="font-medium">
                    {Math.floor((Date.now() - new Date(job.postedDate).getTime()) / (1000 * 60 * 60 * 24))} days ago
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
