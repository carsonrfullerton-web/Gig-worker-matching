import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Search, MapPin, Clock, DollarSign, Briefcase, Star, TrendingUp } from "lucide-react";
import { type Job, type MatchResult } from "@shared/schema";

export default function Jobs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortBy, setSortBy] = useState("match");

  const { data: jobs, isLoading: jobsLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const { data: matches, isLoading: matchesLoading } = useQuery<MatchResult[]>({
    queryKey: ["/api/matches"],
  });

  const getMatchScore = (jobId: string) => {
    return matches?.find(m => m.jobId === jobId)?.matchScore || 0;
  };

  const getMatchReasoning = (jobId: string) => {
    return matches?.find(m => m.jobId === jobId)?.reasoning || "";
  };

  const filteredAndSortedJobs = jobs
    ?.filter(job => {
      const matchesSearch = 
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.requiredSkills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesCategory = categoryFilter === "all" || job.jobType === categoryFilter;
      
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === "match") {
        return getMatchScore(b.id) - getMatchScore(a.id);
      } else if (sortBy === "pay") {
        return b.payRangeMax - a.payRangeMax;
      } else {
        return new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime();
      }
    }) || [];

  const isLoading = jobsLoading || matchesLoading;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <Link href="/">
            <a className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">GigMatch</span>
            </a>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/applications">
              <Button variant="ghost" data-testid="button-my-applications">My Applications</Button>
            </Link>
            <Link href="/profile">
              <Button variant="outline" data-testid="button-edit-profile">Edit Profile</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Stats Bar */}
      <div className="border-b bg-card/50">
        <div className="container mx-auto px-6 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Briefcase className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold">{jobs?.length || 0}</div>
                <div className="text-sm text-muted-foreground">Total Jobs</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                <Star className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {filteredAndSortedJobs.filter(j => getMatchScore(j.id) >= 80).length}
                </div>
                <div className="text-sm text-muted-foreground">High Matches</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {jobs?.filter(j => j.featured).length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Featured</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {jobs?.filter(j => {
                    const daysSince = Math.floor((Date.now() - new Date(j.postedDate).getTime()) / (1000 * 60 * 60 * 24));
                    return daysSince <= 7;
                  }).length || 0}
                </div>
                <div className="text-sm text-muted-foreground">New This Week</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        {/* Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search jobs by title, company, or skills..." 
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48" data-testid="select-category">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="development">Development</SelectItem>
                <SelectItem value="design">Design</SelectItem>
                <SelectItem value="writing">Writing</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48" data-testid="select-sort">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="match">Best Match</SelectItem>
                <SelectItem value="pay">Highest Pay</SelectItem>
                <SelectItem value="recent">Most Recent</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Job Listings */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredAndSortedJobs.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No jobs found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filters to find more opportunities
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedJobs.map((job) => {
              const matchScore = getMatchScore(job.id);
              const matchColor = 
                matchScore >= 80 ? "text-green-600" : 
                matchScore >= 60 ? "text-orange-600" : 
                "text-muted-foreground";
              
              return (
                <Card key={job.id} className={`hover-elevate transition-all ${job.featured ? "border-primary" : ""}`}>
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-job-title mb-1 truncate">
                          {job.title}
                        </CardTitle>
                        <div className="text-sm text-muted-foreground">{job.company}</div>
                      </div>
                      {matchScore > 0 && (
                        <div className="flex flex-col items-center gap-1 shrink-0">
                          <div className={`text-match-score ${matchColor}`}>
                            {matchScore}%
                          </div>
                          <Badge variant="secondary" className="text-xs gap-1">
                            <Sparkles className="h-3 w-3" />
                            AI Match
                          </Badge>
                        </div>
                      )}
                    </div>
                    {job.featured && (
                      <Badge className="w-fit mt-2">Featured</Badge>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="h-4 w-4 shrink-0" />
                        <span className="truncate">{job.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <DollarSign className="h-4 w-4 shrink-0" />
                        <span>${job.payRangeMin} - ${job.payRangeMax}/hr</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="h-4 w-4 shrink-0" />
                        <span>{new Date(job.postedDate).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {job.requiredSkills.slice(0, 3).map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {job.requiredSkills.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{job.requiredSkills.length - 3}
                        </Badge>
                      )}
                    </div>

                    <Link href={`/job/${job.id}`}>
                      <Button className="w-full" data-testid={`button-view-job-${job.id}`}>
                        View Details
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
