import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RequireProfile } from "@/components/require-profile";
import Landing from "@/pages/landing";
import WorkerProfile from "@/pages/worker-profile";
import Jobs from "@/pages/jobs";
import JobDetail from "@/pages/job-detail";
import Applications from "@/pages/applications";
import PostJob from "@/pages/post-job";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/profile" component={WorkerProfile} />
      <Route path="/post-job" component={PostJob} />
      <Route path="/jobs">
        <RequireProfile>
          <Jobs />
        </RequireProfile>
      </Route>
      <Route path="/job/:id">
        <RequireProfile>
          <JobDetail />
        </RequireProfile>
      </Route>
      <Route path="/applications">
        <RequireProfile>
          <Applications />
        </RequireProfile>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
