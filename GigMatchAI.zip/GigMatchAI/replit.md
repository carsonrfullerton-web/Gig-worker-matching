# GigMatch - AI-Powered Job Matching Platform

## Overview

GigMatch is an AI-powered job matching platform designed to connect gig workers with their ideal opportunities through intelligent skill-based matching. The platform combines a professional, polished interface with AI-driven job recommendations, featuring a comprehensive worker profile system, job listings, application tracking, and automated matching scores powered by OpenAI's GPT-5 model.

The application provides a seamless experience for both workers and employers: workers can create detailed profiles showcasing their skills and preferences, while the AI analyzes compatibility with available positions and provides transparent match scores with skill-level breakdowns.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework:** React with TypeScript
- **Routing:** Wouter (lightweight client-side routing)
- **State Management:** TanStack Query (React Query) for server state management
- **UI Components:** Radix UI primitives with shadcn/ui component library
- **Styling:** Tailwind CSS with custom design system based on "New York" style preset
- **Form Handling:** React Hook Form with Zod validation via @hookform/resolvers

**Design System:**
- Typography: Inter font family (400, 500, 600, 700 weights) for body and UI elements
- Color scheme: Neutral base colors with HSL-based theming supporting light/dark modes
- Component styling: Custom CSS variables for consistent theming across cards, buttons, popovers, and interactive elements
- Spacing: Tailwind utility classes with consistent rhythm using units of 2, 4, 6, 8, 12, 16, 20
- Layout: Responsive grid system (3-column desktop → 2-column tablet → 1-column mobile)

**Key Pages:**
- Landing: Marketing page with feature highlights and testimonials
- Worker Profile: Form-based profile creation/editing with skill management
- Jobs: Browsable job listings with AI match scores, search, and filtering
- Job Detail: Individual job view with detailed match breakdown and application functionality
- Applications: Dashboard for tracking submitted applications with status indicators
- Post Job: Form for employers to create job postings

**Route Protection:**
- RequireProfile component wraps protected routes
- Redirects to profile creation if worker profile doesn't exist
- Loading states with skeleton components for smooth UX

### Backend Architecture

**Technology Stack:**
- **Runtime:** Node.js with Express.js
- **Language:** TypeScript with ES modules
- **Database ORM:** Drizzle ORM configured for PostgreSQL
- **AI Integration:** OpenAI API (GPT-5 model)
- **Build Tools:** Vite for frontend bundling, esbuild for backend bundling

**Data Storage:**
- **Primary Storage:** In-memory storage (MemStorage class) with interface abstraction (IStorage)
- **Database Schema:** Drizzle-defined schemas for workers, jobs, and applications (ready for PostgreSQL migration)
- **Seeded Data:** Sample jobs pre-populated for demonstration purposes

**API Design:**
- RESTful endpoints under `/api` prefix
- Worker routes: `GET /api/worker`, `POST /api/worker`
- Job routes: `GET /api/jobs`, `GET /api/jobs/:id`, `POST /api/jobs`
- Application routes: `GET /api/applications`, `POST /api/apply`
- Matching routes: `GET /api/matches` (all jobs), `GET /api/match/:id` (single job)

**AI Matching System:**
- Dedicated `ai-matcher.ts` module for job-worker compatibility analysis
- Utilizes OpenAI GPT-5 with structured prompts including worker profile, job requirements, and scoring criteria
- Returns JSON response with:
  - Overall match score (0-100)
  - Reasoning explanation (2-3 sentences)
  - Skill-by-skill breakdown with individual match percentages
- Caching and optimization considerations for multiple job matches

**Development Environment:**
- Vite development server with HMR (Hot Module Replacement)
- Custom middleware for request logging with timing
- Error overlay and development tools via Replit plugins
- Session management infrastructure (connect-pg-simple ready for PostgreSQL sessions)

### Data Models

**Worker Schema:**
- Unique identifier, name, email (unique constraint)
- Headline, skills array, experience level (beginner/intermediate/expert)
- Hourly rate, location, availability status
- Optional bio field
- Zod validation via `insertWorkerSchema`

**Job Schema:**
- Unique identifier, title, company
- Description, required skills array, experience level
- Pay range (min/max hourly rates)
- Location, job type categorization
- Posted date, featured flag
- Zod validation via `insertJobSchema`

**Application Schema:**
- Unique identifier linking worker and job
- Match score, application status
- Applied date, skill breakdown (serialized JSON)
- Zod validation via `insertApplicationSchema`

### External Dependencies

**AI Services:**
- OpenAI API for intelligent job matching (GPT-5 model)
- Requires `OPENAI_API_KEY` environment variable

**Database:**
- PostgreSQL via Neon serverless driver (@neondatabase/serverless)
- Connection string via `DATABASE_URL` environment variable
- Drizzle Kit for schema migrations (output to `/migrations` directory)

**UI Component Libraries:**
- Radix UI primitives (18+ component packages) for accessible, unstyled components
- Lucide React for iconography
- date-fns for date formatting and manipulation
- cmdk for command palette functionality
- embla-carousel-react for carousel components

**Development Tools:**
- Replit-specific Vite plugins (cartographer, dev-banner, runtime-error-modal)
- TypeScript for type safety across client, server, and shared code
- Drizzle Zod for automatic schema-to-Zod validation generation

**Build & Deployment:**
- Vite for client-side bundling (outputs to `dist/public`)
- esbuild for server-side bundling (ESM format, external packages)
- Environment-aware configuration (development vs. production modes)